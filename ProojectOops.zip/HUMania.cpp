#include<iostream>
#include "HUMania.hpp"
#include <vector>
using namespace std;
// 257, 24, 173, 134
// 257, 151, 173, 134
// 540,370,193,115
Unit killerfish = {{201,97,49,39}, {201,97,49,39}};
Unit butterflies={{257,24,173,134},{30, 40, 50, 50}};
Unit bees={{527, 138, 194, 231},{30, 40, 50, 50}};
// First rectangle is srcRect, second is moverRect
// these values are taken from the corresponding image in assets file
// use spritecow.com to find exact values of other asset images



vector<Unit> killerfish_;
vector<Unit>butterflies_;
vector<Unit>bees_;
//create 2 more vectors for bees and butterflies

void drawObjects(SDL_Renderer* gRenderer, SDL_Texture* assets){

    static int frame = 0; //using static so everytime when function is called frame isnt 0
    // pigeons[i].moverRect.x+=2;
    // SDL_RenderCopy(gRenderer, assets, &pigeons[i].srcRect, &pigeons[i].moverRect);
    // // this functios is drawing one pigeon only right now
    for(int i=0;i <killerfish_.size();i++){
            // int currentframe=pigeonsframes[i];
            
            
            //using if conditions to check which position should be displayed
            if(frame==0){
                killerfish_[i].srcRect={201, 97, 49, 39};
                
                }
            else if(frame==1){
                killerfish_[i].srcRect={257, 98, 61, 38};
                
            }
            else if(frame==2){
                killerfish_[i].srcRect={320, 98, 62, 38};
                
            }
            if (killerfish_[i].moverRect.x >= 999){
             killerfish_[i].moverRect.x = -killerfish_[i].moverRect.w;
        };
            killerfish_[i].moverRect.x += 5;
            SDL_RenderCopy(gRenderer, assets, &killerfish_[i].srcRect, &killerfish_[i].moverRect);
            frame = (frame+1) % 3;
            //mod by 3 since there are 3 frames
            //incrementing by 1
            
            

        }
        //did the same for butterflies and bees
    for(int i=0;i<butterflies_.size();i++){
         if(frame==0){
                butterflies_[i].srcRect={257,24,173,134};
                
                }
            else if(frame==1){
                butterflies_[i].srcRect={257, 182, 192, 214};
                
            }
            else if(frame==2){
                butterflies_[i].srcRect={248, 432, 248, 179};
                
            }
            if (butterflies_[i].moverRect.x >= 999){
             butterflies_[i].moverRect.x = -butterflies_[i].moverRect.w;
        };
            butterflies_[i].moverRect.x += 5;
            SDL_RenderCopy(gRenderer, assets, &butterflies_[i].srcRect, &butterflies_[i].moverRect);
            
             frame = (frame + 1) % 3;
            

    }
    for(int i=0;i<bees_.size();i++){
         if(frame==0){
                bees_[i].srcRect={527, 138, 194, 115};
                
                }
            else if(frame==1){
                bees_[i].srcRect={527, 254, 194, 115};
               
            }
            else if(frame==2){
                bees_[i].srcRect={540, 370, 193, 115};
                
            }
            if (bees_[i].moverRect.x >= 999){
             bees_[i].moverRect.x = -bees_[i].moverRect.w;
        };
            bees_[i].moverRect.x += 5;
            SDL_RenderCopy(gRenderer, assets, &bees_[i].srcRect, &bees_[i].moverRect);
             frame = (frame + 1) % 3;
            

    }
    // this functios is drawing one pigeon only right now
    //SDL_RenderCopy(gRenderer, assets, &pigeon.srcRect, &pigeon.moverRect);


    // TODO: Write code to iterate over all the vectors and draw objects here: 
    
    
   // pigeon.moverRect.x+=2; // moves the pigeon two pixel towards right
    // changing the srcRect to other positions of pigeon will make the fly animation
    // SDL_RenderPresent is already called in game.cpp file, you don't need to call here
}

void createObject(int x, int y){
    int randomAnimal= 0;  // Assuming you have 3 poses

    Unit newObject; //making an object of type new
    
    // Set srcRect based on the selected random pose
    if (randomAnimal==0){
        killerfish_.push_back({201, 97, 49, 39});
        killerfish_.push_back({257, 98, 61, 38});
        killerfish_.push_back({320, 98, 62, 38});
   
    // Set moverRect and add the new pigeon to the vector
        newObject.moverRect = {x, y, 50, 50};  // Adjust the size and position as needed
        killerfish_.push_back(newObject);
    }
    
    // if(randomAnimal==1){
    //     butterflies_.push_back({257,24,173,134});
    //     butterflies_.push_back({257, 182, 192, 214});
    //     butterflies_.push_back({248, 432, 248, 179});
    //     newObject.moverRect = {x, y, 50, 50};  // Adjust the size and position as needed
    //     butterflies_.push_back(newObject);
    // }
    // if(randomAnimal==2){
    //       bees_.push_back({527, 138, 194, 115});
    //       bees_.push_back({527, 254, 194, 115});
    //       bees_.push_back({540, 370, 193, 115});
    //       newObject.moverRect = {x, y, 50, 50};  // Adjust the size and position as needed
    //       bees_.push_back(newObject);
    //   }
    // TODO: create an object randomly, and push it into corresponding vector
    std::cout<<"Mouse clicked at: "<<x<<" -- "<<y<<std::endl;
}

